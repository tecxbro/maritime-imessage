/* One shared liquid material: existing lens refraction and liquidGL-derived rim.
 * The GPU paints only the control strip, on demand; no page capture or textures.
 * Every host receives the same rounded-box lens maps and clear backdrop material.
 * No remote screenshot requests, DOM capture loop, or replacement input layer.
 */
(() => {
  'use strict';
  const card = document.getElementById('card');
  if (!card?.classList.contains('live-card')) return;
  const bar = document.getElementById('bar');
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const transparency = matchMedia('(prefers-reduced-transparency: reduce)');
  card.dataset.glass = transparency.matches ? 'opaque' : 'css';
  const buttons = [...bar.querySelectorAll(':scope > button')];
  // Reuse the existing lens implementation for every host, without browser sniffing.
  // CSS keeps the same clear base material when a host cannot composite SVG filters.
  card.dataset.glassMaterial = 'unified-liquid-20261030';
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('aria-hidden', 'true');
  svg.style.cssText = 'position:absolute;width:0;height:0;pointer-events:none';
  const defs = document.createElementNS(ns, 'defs');
  svg.append(defs); card.append(svg);
  const maps = new Map();
  for (const button of buttons) {
    const filter = document.createElementNS(ns, 'filter');
    filter.id = 'glass-refraction-' + button.id;
    filter.setAttribute('filterUnits', 'userSpaceOnUse');
    filter.setAttribute('color-interpolation-filters', 'sRGB');
    filter.setAttribute('x', '0'); filter.setAttribute('y', '0');
    const image = document.createElementNS(ns, 'feImage');
    image.setAttribute('result', 'lens'); image.setAttribute('preserveAspectRatio', 'none');
    const displacement = document.createElementNS(ns, 'feDisplacementMap');
    displacement.setAttribute('in', 'SourceGraphic'); displacement.setAttribute('in2', 'lens');
    displacement.setAttribute('xChannelSelector', 'R'); displacement.setAttribute('yChannelSelector', 'G');
    displacement.setAttribute('scale', '22');
    filter.append(image, displacement); defs.append(filter);
    maps.set(button, { filter, image, width: 0, height: 0 });
  }
  function updateRefraction() {
    for (const [button, map] of maps) {
      if (transparency.matches) { button.style.removeProperty('backdrop-filter'); button.style.removeProperty('-webkit-backdrop-filter'); continue; }
      const width = Math.round(button.clientWidth), height = Math.round(button.clientHeight);
      if (!width || !height) continue;
      if (width !== map.width || height !== map.height) {
        // A rounded-box normal map, generated only while the control changes size.
        // Half-resolution maps are stretched by the compositor; only sizes invalidate them.
        const pixelWidth = Math.ceil(width/2), pixelHeight = Math.ceil(height/2);
        const canvas = map.canvas || (map.canvas = document.createElement('canvas'));
        canvas.width = pixelWidth; canvas.height = pixelHeight;
        const ctx = canvas.getContext('2d'), pixels = ctx.createImageData(pixelWidth, pixelHeight);
        const radius = height / 2, straight = Math.max(0, (width - height) / 2), bevel = height * .22;
        for (let y = 0; y < pixelHeight; y++) for (let x = 0; x < pixelWidth; x++) {
          const px = (x + .5)*width/pixelWidth - width/2, py = (y + .5)*height/pixelHeight - height/2;
          const dx = px - Math.max(-straight, Math.min(straight, px)), length = Math.hypot(dx, py);
          const depth = Math.max(0, radius - length);
          const bend = Math.pow(Math.max(0, 1 - depth / bevel), 2);
          const i = (y * pixelWidth + x) * 4;
          pixels.data[i] = Math.round(128 + (length ? dx / length : 0) * bend * 120);
          pixels.data[i + 1] = Math.round(128 + (length ? py / length : 0) * bend * 120);
          pixels.data[i + 2] = 128; pixels.data[i + 3] = 255;
        }
        ctx.putImageData(pixels, 0, 0);
        map.filter.setAttribute('width', String(width)); map.filter.setAttribute('height', String(height));
        map.image.setAttribute('width', String(width)); map.image.setAttribute('height', String(height));
        map.image.setAttribute('href', canvas.toDataURL());
        map.width = width; map.height = height;
      }
      const filter = 'url("#' + map.filter.id + '") var(--glass-backdrop)';
      button.style.setProperty('backdrop-filter', filter);
      button.style.setProperty('-webkit-backdrop-filter', filter);
    }
  }
  const buttonSizes = new ResizeObserver(updateRefraction);
  buttons.forEach(button => buttonSizes.observe(button));
  updateRefraction();
  let renderer = null, disposed = false, scheduled = false, generation = 0, factory;
  const visible = () => !disposed && !document.hidden && !transparency.matches
    && document.getElementById('pair').classList.contains('hidden')
    && document.getElementById('veil').classList.contains('hide')
    && !bar.classList.contains('hidden')
    && document.getElementById('tasks').classList.contains('hidden');
  const destroy = () => {
    ++generation;
    renderer?.destroy(); renderer = null;
    card.dataset.glass = transparency.matches ? 'opaque' : 'css';
  };
  async function update() {
    if (!visible()) { if (renderer) destroy(); return; }
    if (renderer) return;
    const current = ++generation;
    try {
      factory ||= import('/static/control-glass-renderer.js?v=three-controls-20261030');
      const { createControlGlass } = await factory;
      if (current !== generation || !visible()) return;
      renderer = createControlGlass({container:card, buttons, reducedMotion:motion.matches, onLost:destroy});
      card.dataset.glass = renderer ? 'webgl' : 'css';
    } catch { destroy(); }
  }
  const schedule = () => {
    if (scheduled || disposed) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; update(); });
  };
  const observer = new MutationObserver(schedule);
  for (const element of [bar, document.getElementById('pair'), document.getElementById('veil'), document.getElementById('tasks')]) {
    observer.observe(element, { attributes: true, attributeFilter: ['class'] });
  }
  motion.addEventListener('change', () => { destroy(); schedule(); });
  transparency.addEventListener('change', () => { destroy(); updateRefraction(); schedule(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) destroy(); else schedule(); });
  window.addEventListener('pagehide', () => { destroy(); });
  window.addEventListener('pageshow', schedule);
  // Exposes lifecycle only, never browser credentials or control operations.
  window.cardGlass = { stats: () => renderer?.stats(), draw: () => renderer?.draw(), destroy() { disposed = true; observer.disconnect(); buttonSizes.disconnect(); svg.remove(); buttons.forEach(button => { button.style.removeProperty('backdrop-filter'); button.style.removeProperty('-webkit-backdrop-filter'); }); destroy(); } };
  schedule();
})();
