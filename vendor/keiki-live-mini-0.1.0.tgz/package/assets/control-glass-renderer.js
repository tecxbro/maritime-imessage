/* Three-control optical renderer, derived from liquidGL's rounded-box/bevel model.
 * Copyright (c) NaughtyDuk, MIT: /static/vendor/liquidgl/LICENSE
 * Reference: liquidGL v3.0.0, 88f681ab7035fd55b04f63edff1841e32c4199e9.
 * No page capture, textures, video, workers, stacked lenses, or perpetual ticker.
 */
export function createControlGlass({ container, buttons, reducedMotion, onLost }) {
  const canvas = document.createElement('canvas');
  canvas.dataset.glassRenderer = 'controls';
  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.cssText = 'position:absolute;z-index:6;pointer-events:none';
  const gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false });
  if (!gl) return null;
  const shaders = [];
  let program, buffer;
  const compile = (type, source) => {
    const shader = gl.createShader(type); shaders.push(shader);
    gl.shaderSource(shader, source); gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error('Glass shader unavailable');
    return shader;
  };
  try {
    program = gl.createProgram();
    gl.attachShader(program, compile(gl.VERTEX_SHADER, `
      attribute vec2 position;
      varying vec2 uv;
      void main(){ uv=position*.5+.5; gl_Position=vec4(position,0.,1.); }
    `));
    gl.attachShader(program, compile(gl.FRAGMENT_SHADER, `
      precision mediump float;
      varying vec2 uv;
      uniform vec2 size, pointer;
      uniform float energy;
      float udRoundBox(vec2 p,vec2 b,float r){
        return length(max(abs(p)-b+r,0.))-r;
      }
      void main(){
        vec2 p=(uv-.5)*(size+6.);
        float radius=min(size.x,size.y)*.5;
        float d=udRoundBox(p,size*.5,radius);
        float inside=1.-smoothstep(-.6,.6,d);
        if(inside<=0.){gl_FragColor=vec4(0.);return;}
        vec2 closest=vec2(clamp(p.x,-size.x*.5+radius,size.x*.5-radius),0.);
        vec2 normal=normalize(p-closest+vec2(.0001));
        float edge=1.-smoothstep(0.,radius*.22,max(-d,0.));
        float rim=1.-smoothstep(.25,1.2,abs(d));
        float light=pow(max(dot(normal,normalize(vec2(-.55,.85))),0.),2.5);
        float touch=exp(-length(p-pointer)/max(radius,1.))*energy;
        float alpha=inside*(rim*(.035+.15*light)+pow(edge,3.)*(.02+.06*touch));
        vec3 color=mix(vec3(.35,.57,.95),vec3(1.),light);
        gl_FragColor=vec4(color*alpha,alpha);
      }
    `));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Glass program unavailable');
    gl.useProgram(program);
    buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,1,1]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, 'position');
    gl.enableVertexAttribArray(position); gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  } catch {
    shaders.forEach(shader => gl.deleteShader(shader));
    if (program) gl.deleteProgram(program);
    if (buffer) gl.deleteBuffer(buffer);
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return null;
  }
  const uniforms = Object.fromEntries(['size','pointer','energy'].map(name => [name, gl.getUniformLocation(program, name)]));
  container.append(canvas);
  let raf = 0, disposed = false, until = 0, draws = 0;
  const pointer = { x: -10000, y: -10000, energy: 0, target: 0 };
  function draw() {
    if (disposed || document.hidden || gl.isContextLost()) return;
    const rects = buttons.map(button => button.getBoundingClientRect());
    const bounds = container.getBoundingClientRect();
    const left = Math.min(...rects.map(r => r.left)) - 3;
    const top = Math.min(...rects.map(r => r.top)) - 3;
    const width = Math.ceil(Math.max(...rects.map(r => r.right)) - left + 3);
    const height = Math.ceil(Math.max(...rects.map(r => r.bottom)) - top + 3);
    const dpr = Math.min(1.5, window.devicePixelRatio || 1);
    const pixelWidth = Math.ceil(width * dpr), pixelHeight = Math.ceil(height * dpr);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth; canvas.height = pixelHeight;
    }
    canvas.style.left = (left - bounds.left) + 'px'; canvas.style.top = (top - bounds.top) + 'px';
    canvas.style.width = width + 'px'; canvas.style.height = height + 'px';
    gl.clearColor(0,0,0,0); gl.clear(gl.COLOR_BUFFER_BIT);
    for (const r of rects) {
      gl.viewport(Math.floor((r.left-left-3)*dpr), Math.floor((top+height-r.bottom-3)*dpr), Math.ceil((r.width+6)*dpr), Math.ceil((r.height+6)*dpr));
      gl.uniform2f(uniforms.size, r.width, r.height);
      gl.uniform2f(uniforms.pointer, pointer.x-r.left-r.width/2, r.top+r.height/2-pointer.y);
      gl.uniform1f(uniforms.energy, reducedMotion ? 0 : pointer.energy);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    ++draws;
  }
  function invalidate(duration = 0) {
    if (disposed) return;
    until = Math.max(until, performance.now() + duration);
    if (!raf) raf = requestAnimationFrame(frame);
  }
  function frame(now) {
    raf = 0;
    pointer.energy += (pointer.target-pointer.energy) * .22;
    const settling = Math.abs(pointer.target-pointer.energy) > .002;
    if (!settling) pointer.energy = pointer.target;
    draw();
    if (settling || now < until) invalidate();
  }
  const enter = event => { if (reducedMotion) return; pointer.x=event.clientX; pointer.y=event.clientY; pointer.target=.65; invalidate(); };
  const leave = () => { pointer.target=0; invalidate(); };
  const press = event => { enter(event); invalidate(reducedMotion ? 0 : 200); };
  const transition = () => invalidate(reducedMotion ? 0 : 520);
  const observer = new ResizeObserver(() => invalidate());
  buttons.forEach(button => {
    observer.observe(button);
    button.addEventListener('pointermove', enter, {passive:true});
    button.addEventListener('pointerleave', leave, {passive:true});
    button.addEventListener('pointerdown', press, {passive:true});
    button.addEventListener('pointerup', leave, {passive:true});
    button.addEventListener('pointercancel', leave, {passive:true});
    button.addEventListener('transitionrun', transition);
  });
  const loss = event => { event.preventDefault(); onLost(); };
  canvas.addEventListener('webglcontextlost', loss);
  window.addEventListener('resize', transition);
  window.visualViewport?.addEventListener('resize', transition);
  window.visualViewport?.addEventListener('scroll', transition);
  draw();
  return {
    draw,
    stats: () => ({ draws, framePending: !!raf, pixels: canvas.width*canvas.height, width: canvas.width, height: canvas.height, textures: 0 }),
    destroy() {
      if (disposed) return;
      disposed = true; cancelAnimationFrame(raf); raf=0; observer.disconnect();
      buttons.forEach(button => {
        button.removeEventListener('pointermove', enter); button.removeEventListener('pointerleave', leave);
        button.removeEventListener('pointerdown', press); button.removeEventListener('pointerup', leave);
        button.removeEventListener('pointercancel', leave); button.removeEventListener('transitionrun', transition);
      });
      canvas.removeEventListener('webglcontextlost', loss);
      window.removeEventListener('resize', transition);
      window.visualViewport?.removeEventListener('resize', transition);
      window.visualViewport?.removeEventListener('scroll', transition);
      if (!gl.isContextLost()) {
        gl.deleteBuffer(buffer); gl.deleteProgram(program); shaders.forEach(shader => gl.deleteShader(shader));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
      }
      canvas.remove(); canvas.width=canvas.height=0;
    },
  };
}
