# Third-party notices

The existing optical control renderer derives rounded-box/bevel geometry from liquidGL (MIT). It is not the complete liquidGL runtime. See licenses/liquidgl.txt.

The bundled noVNC 1.5.0 client retains MPL 2.0 and its third-party licenses under licenses/novnc. Corresponding source: https://github.com/novnc/noVNC/tree/v1.5.0 .
