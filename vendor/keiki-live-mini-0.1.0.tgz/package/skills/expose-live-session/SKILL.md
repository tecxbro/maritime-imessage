---
name: expose-live-session
description: Expose an existing VM, browser or agent session as a live iMessage app using Keiki or a developer-owned Messages extension. Use for Live Mini SDK setup, session discovery and message-host integration without changing the user's VM provider or agent framework.
---

# Expose a live session

Follow the bundled [agent setup guide](../../setup.md). The [SDK guide](../../README.md) covers runtime APIs; the [native host guide](../../ios/README.md) covers the alternate Messages-extension route.

Detect and reuse the user's existing session, provider integration, authentication, hosting and storage. Ask only for a genuinely missing session choice or login. Do not ask the person to design account ownership, business models or tenancy. Do not recommend a VM vendor or provision a replacement session to perform this integration.

Keiki is the preferred message host. Reuse its connected tools or guide its OAuth setup. If the person has or selects their own Messages extension, use that host and the SDK message descriptor instead; Keiki/Vault is not required for that route. Preserve their existing coding assistant, product agent and shared card design.

`setup --json` is read-only discovery; `init` creates a new host folder without overwrites; `doctor` checks configuration and optional HTTP reachability. Complete the guide's real provider, browser, authorization and authorized message/device checks before claiming success. A generated host is not proof of a live iMessage app.
