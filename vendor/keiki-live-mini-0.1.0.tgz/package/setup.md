# Expose the VM or browser the user already has

Execute this guide when someone gives you this package and asks to bring an existing VM, browser or agent session into iMessage. Keep their current provider, agent framework, backend and hosting. The package's purpose is streaming that existing session, not selecting a new VM service.

## Discover, then choose the message host

Run the installed `keiki-live-mini setup --json` in the app directory. It is read-only discovery: existing connection-variable names, project manifests, dependencies, hosting/framework clues and Keiki connection clues. Inspect the relevant application code to confirm the session. Do not print credentials.

Reuse a working viewer URL, scoped VNC grant or CDP connection first. This includes a session already managed through the user's messaging/agent platform. If needed, ask the existing provider client for a viewer grant on that same session. Do not create another computer or open another provider account merely to expose it.

Keiki is the preferred message host. Reuse an authenticated connection if available; otherwise guide its OAuth sign-in. If the person already has their own Messages extension or explicitly chooses that route, use it. If this choice is unresolved, the relevant question is only: **use Keiki, or your own iMessage app?** Do not ask about business models, developer-owned versus customer-owned accounts, or tenancy.

If several actual sessions exist, ask which to expose. If none is identifiable, ask where the existing VM/browser runs or for its connection. Infer everything else from the app and current signed-in tools. The user's answer is a session choice or login, not a request to design infrastructure.

## Connect the existing session

Read the [SDK API guide](README.md). Use `attachedProvider` for an iframe, VNC or CDP connection, or adapt the application's existing integration through `LiveProvider.getState` and `getViewer`. For another provider, consult its current official API and reuse the installed client. Add optional lifecycle/automation hooks only when supported. Never silently replace the provider or fake a stream with screenshots.

Mount the SDK in the existing backend. Keep provider API keys and CDP credentials there. Reuse current authentication and ownership resolution. For a standalone session with no existing backend:

```sh
keiki-live-mini init --transport cdp --delivery keiki
# Transport may also be iframe or rfb.
# Delivery may be messages for a developer-owned Messages extension.
```

This creates a new host folder and refuses to overwrite one. It attaches the supplied session; it does not provision a VM, create accounts, send messages or deploy a cloud service. Use the current hosting and persistence when present. A simple Node host can use a private file; multi-instance/serverless applications should use their existing shared store. Platform-specific adapters are optional.

Private runtime values belong in the host's secret store or ignored environment file. Do not put credentials in prompts, chat, source or native app bundles. Reuse a known authenticated owner; where one is genuinely missing, obtain the sender/account that should be allowed to open this particular VM. Do not expose one global VM to every contact.

## Preferred route: Keiki

Use an existing Keiki MCP connection or guide the supported OAuth connection to `https://onkeiki.com/mcp`. Read the current [Keiki setup guide](https://onkeiki.com/setup.md) and [MCP documentation](https://onkeiki.com/docs/mcp). Discover the live tool schemas, then confirm the organization, role and selected agent. If access/invitation is missing, retain local progress and identify that exact blocker.

Reuse the appropriate Keiki agent and preserve unrelated tools, instructions, channels and connections. Keiki login does not log in to the VM provider or replace the user's coding assistant/product agent. Reuse the existing VM provider account; if it needs sign-in, use its supported authentication flow privately.

Register `live.keikiTools()` on that agent. It returns one app presentation with `live: true`. Use stable intent IDs on retry. The generated host narrows the tool to the configured adapter and supplies identity/tool backend configuration objects. Merge those into the selected agent; do not overwrite its whole configuration.

Use the actual signed-tool verifier exposed as `verifyKeikiWebhook`, backed by `@onkeiki/agents/cloud`; external-harness turn signatures are a different contract. Configure the matching identity/webhook signing secret. Keep the app's existing identity/resource mapping where present. See [conversation authentication](https://onkeiki.com/docs/conversation-auth).

Verify Keiki access, Dynamic UI, an eligible dedicated iMessage line and Keiki Vault on the recipient's supported device. These are delivery prerequisites. Follow the user's actual authorization for any line purchase, account connection or test send; do not message unrelated contacts to finish setup.

## Alternate route: their own Messages app

Read [ios/README.md](ios/README.md) and inspect the existing Messages extension or compatible launcher. Call `live.open({...input, delivery: 'messages'})` from the authenticated backend and give the resulting message descriptor to that host. There is no Keiki login requirement for this route.

Apple's MSMessageLiveLayout uses a Messages extension view inside the transcript, with an alternate template for devices without the app. An ordinary HTTPS URL does not create a live bubble by itself. Reuse the user's existing native host; if needed, adapt the packaged `ios/LiveMessagesViewController.swift` reference in their own Messages extension target, with their bundle identity, signing and HTTPS origin. The installed extension must launch/render the SDK page and insert/send the native message through the active conversation. Do not invent an Apple server messaging API or claim interoperability with a launcher whose contract you have not checked.

## Verify the result

Run `keiki-live-mini doctor --transport cdp --delivery keiki --origin https://YOUR_HOST --json`, adjusting connection and delivery. This checks configuration-variable names and optional host/assets reachability, not streaming or account validity.

Verify the real provider connection, actual backend authorization, another owner's rejection and grant renewal. Inspect the real HTTPS card in a browser: square/full-frame fit, the three existing glass controls, supported takeover/handback, and reopening without a replacement session. Polling/disconnection must not create another billable session.

For Keiki, deliver one authorized app presentation and inspect its delivery result. For a custom Messages host, build/test that extension and use the active conversation to stage/send the message. Verify native behavior on a supported device with the required app installed. API acceptance, generated source or an HTTP 200 is not device-delivery proof.

Report the existing session used, delivery route, host URL, verified behavior and any exact outstanding login, extension build or device check. Preserve completed work through a blocker. The person should not have to understand your infrastructure choices to use the result.
