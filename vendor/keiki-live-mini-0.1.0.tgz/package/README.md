# Live VM/browser sessions in iMessage

Give your existing VM or browser stream to this SDK and expose it as an interactive iMessage app. Keep your current agent, VM provider, backend, hosting and storage.

**Keiki is the preferred delivery path. Your own Messages extension is also supported.** The viewer and its existing glass controls are shared. The package does not select a VM vendor, require a particular cloud host, or create a replacement computer.

## Give it to your coding agent

> Read `node_modules/keiki-live-mini/setup.md`. Expose my existing VM or browser as a live iMessage app. Reuse my current provider, agent and hosting. Prefer Keiki; use my own Messages extension if I choose that route.

The package includes an agent skill at `skills/expose-live-session/SKILL.md`. Any coding assistant can read the guide directly; it is not tied to a model or framework.

```sh
# This package is currently supplied as a local archive, not published on npm.
npm install ./keiki-live-mini-0.1.0.tgz ws
npx --no-install keiki-live-mini setup --json
npx --no-install keiki-live-mini guide
```

Setup inspects the existing app and connection-variable names without printing credentials. It does not change accounts or contact a VM provider. When a small standalone host is needed:

```sh
npx --no-install keiki-live-mini init --transport cdp --delivery keiki
# Or: --transport iframe / --transport rfb
# Or: --delivery messages for your own Messages extension
```

`init` creates a new `live-mini/` folder and refuses to overwrite one. Integrate into the current backend instead when one already exists. See the generated README for private runtime configuration. No particular database service or cloud deployment is required. The default Node starter uses local file persistence; use your existing shared store in multi-instance/serverless applications. An optional Worker host is available with `--target worker` for projects that already use that platform.

## Attach your existing session

```ts
import {createLiveMini, attachedProvider} from 'keiki-live-mini';
import {FileStore, nodeRuntime, createNodeServer} from 'keiki-live-mini/node';

const live = createLiveMini({
  origin: 'https://your-existing-host.example',
  store: new FileStore('./data/live-mini.json'),
  runtime: nodeRuntime(),
  providers: [attachedProvider({
    id: 'existing-session', label: 'Live computer', transport: 'cdp',
    getViewer: async () => ({transport: 'cdp', cdpUrl: await yourExistingSession.getConnection()}),
  })],
});

// Inside your authenticated backend or Keiki tool:
const card = await live.open({
  owner: authenticatedUser.id,
  providerId: 'existing-session',
  sessionKey: yourExistingSession.id,
  intentId: stableToolCallId,
});
// Return card from the Keiki tool. Mount the SDK in your existing server,
// or use createNodeServer(live).listen(8787) for a small standalone host.
```

Supported connection shapes:

```ts
{transport: 'iframe', url, expiresAt?, readiness?, refresh?}
{transport: 'rfb', wsUrl, expiresAt}
{transport: 'cdp', cdpUrl, headers?, targetId?, expiresAt?}
```

For a fixed existing connection, `attach({owner, providerId, sessionKey, data: {connection}})` is also available. `attach()` is unmanaged by default. For expiring grants or changing sessions, implement `getViewer` with your existing provider client. Backend API keys and CDP connections stay on the server; a VNC connection must be a browser-usable scoped viewer grant.

## Two ways to deliver it

**Keiki, default:** `open()` returns `{status, url, presentation}`. Return that result from a Keiki tool; Keiki sends one live mini-app card. Prerequisites are Keiki access, an eligible dedicated iMessage line, Dynamic UI enabled and Keiki Vault on the recipient's supported device. The agent can guide Keiki MCP/OAuth setup. Creating an account alone does not enable cards. See [Keiki iMessage Apps](https://onkeiki.com/docs/imessage-apps).

**Your own iMessage app:** call `open({...args, delivery: 'messages'})`. It returns `{status, url, message: {url, live, caption, subcaption}}` for your native Messages extension or compatible launcher. No Keiki account, API key or Vault installation is required for that route. The extension must actually implement the native host and be installed for the live experience. The SDK does not send an arbitrary native message from a web server. The [reference host and Apple requirements](ios/README.md) explain MSMessageLiveLayout, WKWebView, installation fallback and device verification.

Use a stable intent ID for retries. Both delivery routes reuse the same viewer URL and stream implementation. A plain web link is not an interactive transcript bubble without the native host.

## Your provider and agent stay yours

Implement `LiveProvider` with `id`, `label`, `transport`, `getState` and `getViewer`. Register that adapter without changing the renderer. Optional `provision`, `stop`, viewport repair and task/control hooks are available when your existing integration supports them. The SDK contains no VM-provider catalog and runs no general automation agent.

Keep private JSON state in `ctx.data` and checkpoint remote IDs with `await ctx.save()`. Managed provisioning uses shared claims. State requests do not provision sessions; disconnecting a viewer does not stop its VM. Stopping a session and cancelling automation are separate operations. Optional automation hooks can pause/resume your existing runner during handoffs.

iframe input restrictions depend on the provider. A page-load signal is weaker than actual frame readiness; use `readiness: {type, width, height}` when the embedded viewer reports painted frames. CDP streams a selected Chromium page with pointer/keyboard input; it does not include browser audio or a tab-selection toolbar. Unsupported streaming protocols need a transport extension.

## Hosting and authorization

The SDK's `fetch(request)` serves the viewer, assets and Keiki signed opener, returning `null` for unrelated paths. `basePath` and `assetPath` are configurable. For Node, mount `createNodeHandler(live).handler` and `.handleUpgrade` on the current HTTP server. The optional Worker adapter uses platform-native WebSockets. Custom stores implement get/put/delete and atomic claim/release using the app's current persistence.

`live.keikiTools()` supplies webhook definitions compatible with Keiki's cloud client. Configure `webhook: {secret, resolveOwner}` and derive ownership from authenticated context. The generated Keiki starter includes a signed identity callback and a single-owner gate; existing products should keep their existing account/resource resolver. Never accept owner IDs, remote endpoints or credentials from model-controlled tool arguments.

The default viewer link is a bearer credential scoped to that card, valid for 30 days. Do not publish it or log its fragment. Native Face ID or external authorization can be supplied by the host. A successful publish or accepted message is not proof of recipient opening or device rendering.

## Verification

The source workspace tests independent adapters, signed callbacks, storage/claims, existing-session attachment and real local Chromium streaming on Node and Workers. The package also includes setup/scaffold tests and clean consumer checks. Native Messages reference code requires an iOS SDK build and real-device verification in the developer's own app.
