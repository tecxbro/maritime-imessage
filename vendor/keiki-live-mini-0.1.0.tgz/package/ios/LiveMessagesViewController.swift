import UIKit
import Messages
import WebKit

/// Decode the `message` field returned by live.open(..., delivery: "messages").
struct LiveMessageDescriptor: Decodable {
    let url: URL
    let live: Bool
    let caption: String?
    let subcaption: String?
}

/// Add to your own Messages extension target. Configure LiveMiniOrigin in its Info.plist.
/// The containing app's authenticated backend supplies descriptors; no provider API key belongs here.
final class LiveMessagesViewController: MSMessagesAppViewController, WKNavigationDelegate {
    private var webView: WKWebView!
    private let statusLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.text = "Choose a live session from your app."
        statusLabel.numberOfLines = 0
        statusLabel.textAlignment = .center
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        view.addSubview(statusLabel)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.85)
        ])
    }

    override func willBecomeActive(with conversation: MSConversation) {
        super.willBecomeActive(with: conversation)
        loadViewIfNeeded()
        if let url = conversation.selectedMessage?.url { show(url) }
    }

    override func contentSizeThatFits(_ size: CGSize) -> CGSize {
        if presentationStyle == .transcript { return CGSize(width: size.width, height: size.width) }
        return size
    }

    /// Call from the extension's session picker after your backend authorizes the session.
    /// Insertion stages a draft; the person sends it in Messages.
    func stage(_ descriptor: LiveMessageDescriptor) {
        guard let conversation = activeConversation, isAllowed(descriptor.url) else {
            statusLabel.text = "This session URL is not available in this app."
            return
        }
        let alternate = MSMessageTemplateLayout()
        alternate.caption = descriptor.caption ?? "Live session"
        alternate.subcaption = descriptor.subcaption ?? "Install this Messages app to view the live session."
        let message = MSMessage(session: MSSession())
        message.url = descriptor.url
        if descriptor.live { message.layout = MSMessageLiveLayout(alternateLayout: alternate) }
        else { message.layout = alternate }
        conversation.insert(message) { [weak self] error in
            if error != nil { self?.statusLabel.text = "The message could not be inserted. Try again." }
        }
    }

    private func isAllowed(_ url: URL) -> Bool {
        guard let value = Bundle.main.object(forInfoDictionaryKey: "LiveMiniOrigin") as? String,
              let origin = URL(string: value), origin.scheme == "https", url.scheme == "https",
              url.user == nil, url.password == nil, url.host == origin.host,
              (url.port ?? 443) == (origin.port ?? 443) else { return false }
        return true
    }

    private func show(_ url: URL) {
        guard isAllowed(url) else { statusLabel.text = "This session URL is not available in this app."; return }
        statusLabel.isHidden = true
        webView.load(URLRequest(url: url))
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.targetFrame?.isMainFrame == true,
           let url = navigationAction.request.url, !isAllowed(url) { decisionHandler(.cancel); return }
        decisionHandler(.allow)
    }
}
