# Use your own iMessage app

The SDK can return a native Messages descriptor instead of a Keiki presentation:

```ts
// In your existing authenticated backend:
const result = await live.open({
  owner: authenticatedUser.id,
  providerId: 'existing-session',
  sessionKey: existingSession.id,
  intentId: stableIntentId,
  delivery: 'messages',
});
// Return result.message to your own Messages extension after normal app authorization.
```

This route requires no Keiki account, Keiki API key or Keiki Vault installation. Your Messages extension is the launcher and renderer. A bare HTTPS link does not turn into a live bubble automatically.

## Native requirements

- An iOS app with a Messages extension target, built and signed using Xcode and the iOS SDK. Use your own bundle identity and normal Apple distribution process.
- The sender's and recipient's corresponding Messages app installed for the custom live bubble. Devices without it receive the required alternate template; do not promise the live VM there.
- A stable HTTPS SDK viewer origin. Retain your own backend authorization. The descriptor URL can carry a card-scoped bearer fragment; provider keys and CDP credentials stay on the server.

`LiveMessagesViewController.swift` is a reference host to add to your own Messages extension. Set its custom view-controller class as the extension entry point using your target's supported configuration. Add `LiveMiniOrigin` to that extension's Info.plist, containing your HTTPS origin. The controller loads the selected message's SDK URL into WKWebView and sizes the transcript view as a square. Call `stage(_:)` from your existing authenticated session picker; it inserts a draft for the person to send. It is not an arbitrary-recipient server messaging API.

The code uses Apple's MSMessageLiveLayout with an MSMessageTemplateLayout fallback. Messages creates extension view controllers for live transcript bubbles; several instances may coexist. Each loads the same SDK page and shared controls. Normal iOS extension lifecycle and resource limits apply: verify streaming, input, handoff, reopening and recipient behavior on a real device. The TypeScript/HTTP descriptor tests do not establish native iPhone behavior. This repository does not include a signed app or App Store submission.

If using a different existing launcher, first verify that it accepts HTTPS content and renders a live Messages extension view. Integrate through that launcher's actual API. There is no universal Apple HTTP endpoint that embeds a URL in every iMessage app.

Official references:

- [MSMessageLiveLayout](https://developer.apple.com/documentation/messages/msmessagelivelayout): interactive transcript view, alternate layout, installation fallback, multiple controller instances.
- [MSMessagesAppViewController](https://developer.apple.com/documentation/messages/msmessagesappviewcontroller): extension presentation and lifecycle.
- [MSMessage.url](https://developer.apple.com/documentation/messages/msmessage/url): associate the session URL with the native message.
- [MSConversation.insert](https://developer.apple.com/documentation/messages/msconversation/insert(_:completionhandler:)): stage the message from the active extension.
