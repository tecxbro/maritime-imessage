# Existing demo adapters

Private compatibility adapters for the existing demonstration applications. They are distributed separately from the neutral Live Mini SDK and its agent setup context. They are not the SDK provider catalog or a recommendation.
